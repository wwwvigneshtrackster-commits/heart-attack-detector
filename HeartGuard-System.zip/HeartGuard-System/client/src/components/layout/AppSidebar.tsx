import { Link, useLocation } from "wouter";
import { Activity, History, Settings, LogOut, ShieldAlert, HeartPulse, Menu, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { useState } from "react";
import { Button } from "@/components/ui/button";

export function AppSidebar() {
  const [location] = useLocation();
  const [isOpen, setIsOpen] = useState(false);

  const links = [
    { href: "/", label: "Live Monitor", icon: Activity },
    { href: "/history", label: "Alert History", icon: History },
    { href: "/settings", label: "Calibration", icon: Settings },
  ];

  const SidebarContent = () => (
    <>
      <div className="flex h-16 items-center border-b px-6">
        <HeartPulse className="mr-2 h-6 w-6 text-primary animate-pulse" />
        <span className="font-display text-lg font-bold tracking-wider">CARDIO<span className="text-primary">GUARD</span></span>
      </div>
      
      <div className="flex-1 overflow-y-auto py-4">
        <nav className="space-y-1 px-3">
          {links.map((link) => {
            const Icon = link.icon;
            const isActive = location === link.href;
            return (
              <Link key={link.href} href={link.href}>
                <a
                  onClick={() => setIsOpen(false)}
                  className={cn(
                    "group flex items-center rounded-md px-3 py-2 text-sm font-medium transition-colors",
                    isActive
                      ? "bg-sidebar-accent text-sidebar-accent-foreground"
                      : "text-muted-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
                  )}
                >
                  <Icon className="mr-3 h-4 w-4" />
                  {link.label}
                </a>
              </Link>
            );
          })}
        </nav>

        <div className="mt-8 px-3">
          <h3 className="mb-2 px-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            System Status
          </h3>
          <div className="space-y-1">
             <div className="flex items-center px-3 py-2 text-xs text-muted-foreground">
                <span className="mr-2 h-2 w-2 rounded-full bg-emerald-500 animate-pulse"></span>
                Sensor A (Lead I): Active
             </div>
             <div className="flex items-center px-3 py-2 text-xs text-muted-foreground">
                <span className="mr-2 h-2 w-2 rounded-full bg-emerald-500 animate-pulse"></span>
                Sensor B (Lead II): Active
             </div>
             <div className="flex items-center px-3 py-2 text-xs text-muted-foreground">
                <span className="mr-2 h-2 w-2 rounded-full bg-emerald-500"></span>
                ML Inference: Ready
             </div>
          </div>
        </div>
      </div>

      <div className="border-t p-4">
        <div className="flex items-center gap-3 rounded-lg bg-card/50 p-3">
            <div className="h-8 w-8 rounded-full bg-primary/20 flex items-center justify-center">
                <span className="font-bold text-primary text-xs">DR</span>
            </div>
            <div className="flex flex-col">
                <span className="text-xs font-medium">Dr. A. Smith</span>
                <span className="text-[10px] text-muted-foreground">Cardiology Dept.</span>
            </div>
        </div>
      </div>
    </>
  );

  return (
    <>
      {/* Mobile Trigger */}
      <div className="lg:hidden fixed top-4 left-4 z-50">
        <Button variant="outline" size="icon" onClick={() => setIsOpen(!isOpen)} className="bg-background/80 backdrop-blur-md">
          {isOpen ? <X /> : <Menu />}
        </Button>
      </div>

      {/* Desktop Sidebar */}
      <div className="hidden lg:flex h-screen w-64 flex-col border-r bg-sidebar text-sidebar-foreground sticky top-0">
        <SidebarContent />
      </div>

      {/* Mobile Sidebar Overlay */}
      {isOpen && (
        <div className="lg:hidden fixed inset-0 z-40 flex">
          <div className="fixed inset-0 bg-background/80 backdrop-blur-sm" onClick={() => setIsOpen(false)} />
          <div className="relative flex w-64 flex-col border-r bg-sidebar text-sidebar-foreground h-full animate-in slide-in-from-left">
            <SidebarContent />
          </div>
        </div>
      )}
    </>
  );
}
