import { CircularProgressbar, buildStyles } from 'react-circular-progressbar';
import 'react-circular-progressbar/dist/styles.css';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface RiskGaugeProps {
    riskScore: number; // 0 to 100
}

export function RiskGauge({ riskScore }: RiskGaugeProps) {
    let color = "hsl(var(--success))";
    let status = "LOW RISK";

    if (riskScore > 40) {
        color = "hsl(var(--warning))";
        status = "MEDIUM RISK";
    }
    if (riskScore > 75) {
        color = "hsl(var(--destructive))";
        status = "HIGH RISK";
    }

    return (
        <Card className="h-full border-primary/20 bg-card/50 backdrop-blur-sm">
             <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium font-display tracking-wide uppercase text-muted-foreground">
                    ML Risk Assessment
                </CardTitle>
            </CardHeader>
            <CardContent className="flex flex-col items-center justify-center pt-6">
                <div className="h-40 w-40 relative">
                    <CircularProgressbar
                        value={riskScore}
                        text={`${riskScore}%`}
                        styles={buildStyles({
                            textSize: '24px',
                            pathColor: color,
                            textColor: 'hsl(var(--foreground))',
                            trailColor: 'hsl(var(--muted))',
                            pathTransitionDuration: 0.5,
                        })}
                    />
                     <div className="absolute inset-0 rounded-full bg-primary/5 blur-3xl -z-10"></div>
                </div>
                
                <div className="mt-6 text-center">
                    <div className="text-2xl font-display font-bold tracking-widest" style={{ color }}>
                        {status}
                    </div>
                    <p className="mt-2 text-xs text-muted-foreground px-4">
                        Based on XGBoost model analysis of HRV and QT interval data.
                    </p>
                </div>
            </CardContent>
        </Card>
    );
}
