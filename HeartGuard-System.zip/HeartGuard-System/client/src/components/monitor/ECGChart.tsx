import { useState, useEffect, useRef } from 'react';
import { Area, AreaChart, ResponsiveContainer, YAxis, XAxis, Tooltip } from 'recharts';
import { generateECGPoint } from '@/lib/ecg-simulation';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Pause, Play, RefreshCw } from 'lucide-react';

export function ECGChart() {
    const [data, setData] = useState<{ time: number, voltage: number }[]>([]);
    const [isPaused, setIsPaused] = useState(false);
    const [bpm, setBpm] = useState(72);
    const timeRef = useRef(0);
    const requestRef = useRef<number>(0);

    // Buffer to hold data points
    const MAX_POINTS = 200;

    const animate = () => {
        if (!isPaused) {
            timeRef.current += 10; // 10ms increment
            
            // Modulate BPM slightly for realism (HRV)
            const currentBpm = 60 + Math.sin(timeRef.current / 5000) * 15 + (Math.random() * 2);
            setBpm(Math.round(currentBpm));

            const newPoint = {
                time: timeRef.current,
                voltage: generateECGPoint(timeRef.current * (currentBpm/60)) // Adjust speed by BPM
            };

            setData(prev => {
                const newData = [...prev, newPoint];
                if (newData.length > MAX_POINTS) {
                    return newData.slice(newData.length - MAX_POINTS);
                }
                return newData;
            });
        }
        requestRef.current = requestAnimationFrame(animate);
    };

    useEffect(() => {
        requestRef.current = requestAnimationFrame(animate);
        return () => cancelAnimationFrame(requestRef.current);
    }, [isPaused]);

    return (
        <Card className="col-span-2 h-full border-primary/20 bg-card/50 backdrop-blur-sm">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium font-display tracking-wide uppercase text-muted-foreground">
                    Live ECG Feed (Lead II)
                </CardTitle>
                <div className="flex items-center space-x-2">
                    <span className="font-mono text-xs text-primary animate-pulse">REC ●</span>
                    <Button variant="ghost" size="icon" className="h-8 w-8 btn-3d bg-secondary hover:bg-secondary/80" onClick={() => setIsPaused(!isPaused)}>
                        {isPaused ? <Play className="h-3 w-3" /> : <Pause className="h-3 w-3" />}
                    </Button>
                </div>
            </CardHeader>
            <CardContent>
                <div className="h-[250px] w-full">
                    <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={data}>
                            <defs>
                                <linearGradient id="colorVoltage" x1="0" y1="0" x2="0" y2="1">
                                    <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3}/>
                                    <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                                </linearGradient>
                            </defs>
                            <XAxis dataKey="time" hide />
                            <YAxis domain={[-1.5, 2]} hide />
                            <Area 
                                type="monotone" 
                                dataKey="voltage" 
                                stroke="hsl(var(--primary))" 
                                strokeWidth={2}
                                fillOpacity={1} 
                                fill="url(#colorVoltage)" 
                                isAnimationActive={false}
                            />
                        </AreaChart>
                    </ResponsiveContainer>
                </div>
                <div className="mt-4 grid grid-cols-4 gap-4 border-t pt-4">
                     <div className="text-center">
                         <div className="text-xs text-muted-foreground uppercase">Rate</div>
                         <div className="text-2xl font-mono font-bold text-foreground">{bpm} <span className="text-xs text-muted-foreground font-sans">BPM</span></div>
                     </div>
                     <div className="text-center">
                         <div className="text-xs text-muted-foreground uppercase">PR Int</div>
                         <div className="text-2xl font-mono font-bold text-foreground">164 <span className="text-xs text-muted-foreground font-sans">ms</span></div>
                     </div>
                     <div className="text-center">
                         <div className="text-xs text-muted-foreground uppercase">QRS Dur</div>
                         <div className="text-2xl font-mono font-bold text-foreground">92 <span className="text-xs text-muted-foreground font-sans">ms</span></div>
                     </div>
                     <div className="text-center">
                         <div className="text-xs text-muted-foreground uppercase">QT/QTc</div>
                         <div className="text-2xl font-mono font-bold text-foreground">412 <span className="text-xs text-muted-foreground font-sans">ms</span></div>
                     </div>
                </div>
            </CardContent>
        </Card>
    );
}
