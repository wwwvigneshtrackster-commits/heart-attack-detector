import { AppSidebar } from "@/components/layout/AppSidebar";
import { ECGChart } from "@/components/monitor/ECGChart";
import { RiskGauge } from "@/components/monitor/RiskGauge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertCircle, CheckCircle2, TrendingUp, Zap } from "lucide-react";
import { useState, useEffect } from "react";

export default function Dashboard() {
    const [riskScore, setRiskScore] = useState(12);
    
    // Simulate risk fluctuating
    useEffect(() => {
        const interval = setInterval(() => {
            const fluctuation = Math.floor(Math.random() * 10) - 5;
            setRiskScore(prev => Math.min(Math.max(prev + fluctuation, 5), 95));
        }, 3000);
        return () => clearInterval(interval);
    }, []);

    return (
        <div className="flex flex-col lg:flex-row min-h-screen bg-background text-foreground font-sans">
            <AppSidebar />
            
            <main className="flex-1 p-4 lg:p-6 space-y-6 overflow-y-auto lg:max-h-screen pt-16 lg:pt-6">
                <header className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
                    <div>
                        <h1 className="text-xl lg:text-2xl font-bold font-display tracking-tight">Patient Monitor</h1>
                        <p className="text-muted-foreground text-xs lg:text-sm">Room 302 • Doe, John (45M)</p>
                    </div>
                    <div className="flex gap-3 w-full sm:w-auto">
                         <div className="flex items-center justify-center px-4 py-2 bg-card rounded-md border text-xs w-full sm:w-auto">
                            <span className="text-muted-foreground mr-2">Signal:</span>
                            <span className="text-success font-medium flex items-center">
                                <CheckCircle2 className="w-4 h-4 mr-1" /> Optimal
                            </span>
                         </div>
                    </div>
                </header>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    <div className="lg:col-span-2 relative overflow-hidden rounded-xl">
                        <div className="scanline"></div>
                        <ECGChart />
                    </div>
                    <RiskGauge riskScore={riskScore} />
                </div>

                <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
                    <Card className="bg-card/50">
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium text-muted-foreground">HRV (SDNN)</CardTitle>
                            <ActivityIcon className="h-4 w-4 text-muted-foreground" />
                        </CardHeader>
                        <CardContent>
                            <div className="text-2xl font-bold">45 <span className="text-sm font-normal text-muted-foreground">ms</span></div>
                            <p className="text-xs text-muted-foreground mt-1">
                                <span className="text-destructive font-medium">↓ 12%</span> from baseline
                            </p>
                        </CardContent>
                    </Card>

                    <Card className="bg-card/50">
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium text-muted-foreground">SpO2</CardTitle>
                            <TrendingUp className="h-4 w-4 text-muted-foreground" />
                        </CardHeader>
                        <CardContent>
                            <div className="text-2xl font-bold">98 <span className="text-sm font-normal text-muted-foreground">%</span></div>
                            <p className="text-xs text-muted-foreground mt-1">
                                <span className="text-success font-medium">Stable</span> over last hour
                            </p>
                        </CardContent>
                    </Card>

                    <Card className="bg-card/50">
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium text-muted-foreground">Respiratory Rate</CardTitle>
                            <Zap className="h-4 w-4 text-muted-foreground" />
                        </CardHeader>
                        <CardContent>
                            <div className="text-2xl font-bold">14 <span className="text-sm font-normal text-muted-foreground">rpm</span></div>
                             <p className="text-xs text-muted-foreground mt-1">
                                Normal range
                            </p>
                        </CardContent>
                    </Card>
                    
                    <Card className="bg-card/50 border-destructive/50 bg-destructive/5">
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium text-destructive">Arrhythmias</CardTitle>
                            <AlertCircle className="h-4 w-4 text-destructive" />
                        </CardHeader>
                        <CardContent>
                            <div className="text-2xl font-bold text-destructive">None</div>
                            <p className="text-xs text-destructive/80 mt-1">
                                Last event: 4h ago (PVC)
                            </p>
                        </CardContent>
                    </Card>
                </div>
            </main>
        </div>
    );
}

function ActivityIcon(props: any) {
    return (
        <svg
            {...props}
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
        >
            <path d="M22 12h-4l-3 9L9 3l-3 9H2" />
        </svg>
    )
}
