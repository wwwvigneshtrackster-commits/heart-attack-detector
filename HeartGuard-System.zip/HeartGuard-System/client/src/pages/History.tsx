import { AppSidebar } from "@/components/layout/AppSidebar";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";

export default function History() {
  const events = [
    { id: 1, timestamp: new Date(2025, 11, 26, 14, 30), type: "Arrhythmia", value: "PVC Detected", risk: "Low" },
    { id: 2, timestamp: new Date(2025, 11, 26, 13, 15), type: "Risk Alert", value: "Risk Score > 80%", risk: "High" },
    { id: 3, timestamp: new Date(2025, 11, 26, 12, 0), type: "Signal Loss", value: "Lead II Disconnected", risk: "Medium" },
    { id: 4, timestamp: new Date(2025, 11, 26, 9, 45), type: "Arrhythmia", value: "Tachycardia (115 BPM)", risk: "Medium" },
    { id: 5, timestamp: new Date(2025, 11, 25, 23, 10), type: "System", value: "Calibration Completed", risk: "Low" },
  ];

  return (
    <div className="flex flex-col lg:flex-row min-h-screen bg-background text-foreground font-sans">
      <AppSidebar />
      <main className="flex-1 p-4 lg:p-6 space-y-6 pt-16 lg:pt-6">
         <header className="mb-6">
            <h1 className="text-xl lg:text-2xl font-bold font-display tracking-tight">Event History</h1>
            <p className="text-muted-foreground text-xs lg:text-sm">Log of all detected anomalies and system alerts.</p>
        </header>

        <div className="rounded-md border bg-card overflow-x-auto">
          <Table className="min-w-[600px] lg:min-w-full">
            <TableHeader>
              <TableRow>
                <TableHead>Timestamp</TableHead>
                <TableHead>Event Type</TableHead>
                <TableHead>Details</TableHead>
                <TableHead>Risk Level</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {events.map((event) => (
                <TableRow key={event.id}>
                  <TableCell className="font-mono text-xs text-muted-foreground">
                    {format(event.timestamp, "yyyy-MM-dd HH:mm:ss")}
                  </TableCell>
                  <TableCell>{event.type}</TableCell>
                  <TableCell>{event.value}</TableCell>
                  <TableCell>
                    <Badge variant={event.risk === "High" ? "destructive" : event.risk === "Medium" ? "outline" : "secondary"} className={event.risk === "Medium" ? "border-warning text-warning" : ""}>
                      {event.risk}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </main>
    </div>
  );
}
