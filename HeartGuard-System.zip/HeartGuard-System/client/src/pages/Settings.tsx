import { AppSidebar } from "@/components/layout/AppSidebar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { toast } from "@/hooks/use-toast";

export default function Settings() {
  const handleSave = () => {
    toast({
      title: "Calibration Saved",
      description: "Sensor threshold parameters have been updated.",
    });
  };

  return (
    <div className="flex flex-col lg:flex-row min-h-screen bg-background text-foreground font-sans">
      <AppSidebar />
      <main className="flex-1 p-4 lg:p-6 space-y-6 overflow-y-auto pt-16 lg:pt-6">
        <header className="mb-6">
            <h1 className="text-xl lg:text-2xl font-bold font-display tracking-tight">System Calibration</h1>
            <p className="text-muted-foreground text-xs lg:text-sm">Configure sensor sensitivity and ML model thresholds.</p>
        </header>

        <div className="grid gap-6 lg:max-w-2xl">
            <Card>
                <CardHeader>
                    <CardTitle>Signal Processing</CardTitle>
                    <CardDescription>Adjust the Pan-Tompkins algorithm parameters.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="space-y-2">
                        <Label>Bandpass Filter Low Cutoff (Hz)</Label>
                        <div className="flex items-center gap-4">
                            <Slider defaultValue={[5]} max={20} step={1} className="flex-1" />
                            <span className="font-mono text-sm w-8">5.0</span>
                        </div>
                    </div>
                    <div className="space-y-2">
                        <Label>Bandpass Filter High Cutoff (Hz)</Label>
                        <div className="flex items-center gap-4">
                            <Slider defaultValue={[15]} max={50} step={1} className="flex-1" />
                            <span className="font-mono text-sm w-8">15.0</span>
                        </div>
                    </div>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>Alert Thresholds</CardTitle>
                    <CardDescription>Define sensitivity for triggering medical alerts.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                     <div className="flex items-center justify-between">
                        <div className="space-y-0.5">
                            <Label>Arrhythmia Detection</Label>
                            <div className="text-xs text-muted-foreground">Enable automatic PVC/PAC detection</div>
                        </div>
                        <Switch defaultChecked />
                    </div>
                    <Separator />
                     <div className="space-y-2">
                        <Label>Risk Score Alert Trigger (%)</Label>
                        <div className="flex items-center gap-4">
                            <Slider defaultValue={[80]} max={100} step={1} className="flex-1" />
                            <span className="font-mono text-sm w-8">80</span>
                        </div>
                    </div>
                </CardContent>
            </Card>

            <div className="flex justify-end gap-3">
                <Button variant="outline" className="btn-3d border-b-4 hover:translate-y-[1px] active:translate-y-[2px]">Reset to Defaults</Button>
                <Button onClick={handleSave} className="btn-3d-primary font-display tracking-wide">Save Configuration</Button>
            </div>
        </div>
      </main>
    </div>
  );
}
