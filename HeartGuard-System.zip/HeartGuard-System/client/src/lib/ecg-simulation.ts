
// Basic simulation of a P-QRS-T wave
// This isn't medically perfect but looks convincing for a mockup

export const generateECGPoint = (t: number) => {
  // Normalize t to 0-1 cycle
  const cycle = 1000; // 1 second per beat (60 BPM base)
  const pos = (t % cycle) / cycle;

  let voltage = 0;

  // Baseline noise
  voltage += (Math.random() - 0.5) * 0.05;

  // P Wave (Atrial depolarization) - small bump
  if (pos > 0.1 && pos < 0.2) {
    voltage += 0.15 * Math.sin((pos - 0.1) * Math.PI * 10);
  }

  // QRS Complex (Ventricular depolarization) - sharp spike
  if (pos > 0.35 && pos < 0.45) {
     if (pos < 0.4) {
         // Q wave (down)
         voltage -= 0.15 * Math.sin((pos - 0.35) * Math.PI * 20);
     } else {
         // R wave (huge up)
         voltage += 1.2 * Math.sin((pos - 0.38) * Math.PI * 40);
     }
  }
  // S wave (down after R)
  if (pos > 0.42 && pos < 0.46) {
      voltage -= 0.25 * Math.sin((pos - 0.42) * Math.PI * 25);
  }

  // T Wave (Ventricular repolarization) - medium bump
  if (pos > 0.6 && pos < 0.75) {
    voltage += 0.25 * Math.sin((pos - 0.6) * Math.PI * 7);
  }

  return voltage;
};

export const useECGData = () => {
  // Logic to be implemented in component for React state management
};
